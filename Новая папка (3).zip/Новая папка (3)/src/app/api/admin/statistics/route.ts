import { NextRequest, NextResponse } from 'next/server'
import { orders } from '@/lib/orders-data'
import { verifyToken } from '@/lib/orders-data'

export async function GET(request: NextRequest) {
  try {
    const token = request.headers.get('authorization')?.replace('Bearer ', '')
    const user = verifyToken(token)
    
    if (!user || (user.role !== 'MIDDLE_ADMIN' && user.role !== 'SUPER_ADMIN')) {
      return NextResponse.json(
        { error: 'Доступ запрещен' },
        { status: 403 }
      )
    }

    // Calculate statistics from mock data
    const stats = {
      successfulOrders: orders.filter(o => o.orderStatus === 'DELIVERED').length,
      failedOrders: orders.filter(o => o.orderStatus === 'FAILED').length,
      pendingOrders: orders.filter(o => o.orderStatus === 'PENDING').length,
      inDeliveryOrders: orders.filter(o => o.orderStatus === 'IN_DELIVERY').length,
      prepaidOrders: orders.filter(o => o.isPrepaid).length,
      unpaidOrders: orders.filter(o => !o.isPrepaid).length,
      cardOrders: orders.filter(o => o.paymentMethod === 'CARD').length,
      cashOrders: orders.filter(o => o.paymentMethod === 'CASH').length,
      dailyCustomers: 0, // Mock data doesn't have this info
      evenDayCustomers: 0, // Mock data doesn't have this info
      oddDayCustomers: 0, // Mock data doesn't have this info
      specialPreferenceCustomers: orders.filter(o => o.specialFeatures && o.specialFeatures.trim() !== '').length,
      orders1200: orders.filter(o => o.calories === 1200).length,
      orders1600: orders.filter(o => o.calories === 1600).length,
      orders2000: orders.filter(o => o.calories === 2000).length,
      orders2500: orders.filter(o => o.calories === 2500).length,
      orders3000: orders.filter(o => o.calories === 3000).length,
      singleItemOrders: orders.filter(o => o.quantity === 1).length,
      multiItemOrders: orders.filter(o => o.quantity >= 2).length
    }

    return NextResponse.json(stats)
  } catch (error) {
    console.error('Error fetching statistics:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}
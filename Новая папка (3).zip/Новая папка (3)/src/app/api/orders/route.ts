import { NextRequest, NextResponse } from 'next/server'
import { orders } from '@/lib/orders-data'
import { verifyToken } from '@/lib/orders-data'

export async function GET(request: NextRequest) {
  try {
    const user = verifyToken(request.headers.get('authorization')?.substring(7) || '')
    
    if (!user) {
      return NextResponse.json({ error: 'Недействительный токен' }, { status: 401 })
    }
    
    if (user.role !== 'MIDDLE_ADMIN' && user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Недостаточно прав' }, { status: 403 })
    }

    // Get query parameters
    const { searchParams } = new URL(request.url)
    const date = searchParams.get('date')
    const filtersParam = searchParams.get('filters')
    let filters = {}
    
    if (filtersParam) {
      try {
        filters = JSON.parse(filtersParam)
      } catch (error) {
        console.error('Error parsing filters:', error)
      }
    }

    // Apply date filter
    let filteredOrders = orders
    if (date) {
      filteredOrders = filteredOrders.filter(order => {
        const orderDate = new Date(order.createdAt).toISOString().split('T')[0]
        return orderDate === date
      })
    }

    // Apply filters
    if (Object.keys(filters).length > 0) {
      filteredOrders = filteredOrders.filter(order => {
        // Status filters
        if (filters.successful && order.orderStatus !== 'DELIVERED') return false
        if (filters.failed && order.orderStatus !== 'FAILED') return false
        if (filters.pending && order.orderStatus !== 'PENDING') return false
        if (filters.inDelivery && order.orderStatus !== 'IN_DELIVERY') return false
        
        // Payment filters
        if (filters.prepaid && !order.isPrepaid) return false
        if (filters.unpaid && order.paymentStatus !== 'UNPAID') return false
        if (filters.card && order.paymentMethod !== 'CARD') return false
        if (filters.cash && order.paymentMethod !== 'CASH') return false
        
        // Order type filters
        if (filters.autoOrders && false) return false // Mock orders are manual
        if (filters.manualOrders && false) return false // Allow manual orders
        
        // Calories filters
        if (filters.calories1200 && order.calories !== 1200) return false
        if (filters.calories1600 && order.calories !== 1600) return false
        if (filters.calories2000 && order.calories !== 2000) return false
        if (filters.calories2500 && order.calories !== 2500) return false
        if (filters.calories3000 && order.calories !== 3000) return false
        
        // Quantity filters
        if (filters.singleItem && order.quantity !== 1) return false
        if (filters.multiItem && order.quantity === 1) return false
        
        return true
      })
    }

    // Transform orders to match frontend format
    const transformedOrders = filteredOrders.map(order => ({
      ...order,
      customerName: order.customer?.name || 'Неизвестный клиент',
      customerPhone: order.customer?.phone || 'Нет телефона',
      deliveryDate: new Date(order.createdAt).toISOString().split('T')[0],
      isAutoOrder: false // Mock orders are manual
    }))

    return NextResponse.json(transformedOrders)

  } catch (error) {
    console.error('Error fetching orders:', error)
    return NextResponse.json({ error: 'Внутренняя ошибка сервера' }, { status: 500 })
  }
}

export async function POST(request: NextRequest) {
  try {
    const user = verifyToken(request.headers.get('authorization')?.substring(7) || '')
    
    if (!user) {
      return NextResponse.json({ error: 'Недействительный токен' }, { status: 401 })
    }
    
    if (user.role !== 'MIDDLE_ADMIN' && user.role !== 'SUPER_ADMIN') {
      return NextResponse.json({ error: 'Недостаточно прав' }, { status: 403 })
    }

    const body = await request.json()
    const { 
      customerName, 
      customerPhone, 
      deliveryAddress, 
      deliveryTime, 
      quantity, 
      calories, 
      specialFeatures, 
      paymentStatus, 
      paymentMethod, 
      isPrepaid,
      date
    } = body

    if (!customerName || !customerPhone || !deliveryAddress || !calories) {
      return NextResponse.json({ error: 'Не все обязательные поля заполнены' }, { status: 400 })
    }

    // Get the highest order number
    const lastOrder = orders.reduce((max, order) => order.orderNumber > max ? order.orderNumber : max, 0)
    const nextOrderNumber = lastOrder + 1

    // Create new order
    const newOrder = {
      id: String(orders.length + 1),
      orderNumber: nextOrderNumber,
      customer: {
        name: customerName,
        phone: customerPhone
      },
      deliveryAddress,
      latitude: 41.316661, // Default coordinates
      longitude: 69.248480,
      deliveryTime: deliveryTime || '12:00',
      quantity: quantity || 1,
      calories: parseInt(calories),
      specialFeatures: specialFeatures || '',
      paymentStatus: paymentStatus || 'UNPAID',
      paymentMethod: paymentMethod || 'CASH',
      orderStatus: 'PENDING',
      isPrepaid: isPrepaid || false,
      createdAt: new Date().toISOString()
    }

    // Add to orders array
    orders.push(newOrder)

    // Transform to match frontend format
    const transformedOrder = {
      ...newOrder,
      customerName: newOrder.customer.name,
      customerPhone: newOrder.customer.phone,
      deliveryDate: date || new Date(newOrder.createdAt).toISOString().split('T')[0],
      isAutoOrder: false
    }

    console.log(`✅ Created manual order: ${transformedOrder.customerName} (#${nextOrderNumber})`)

    return NextResponse.json({ 
      message: 'Заказ успешно создан',
      order: transformedOrder
    })

  } catch (error) {
    console.error('Error creating order:', error)
    return NextResponse.json({ error: 'Внутренняя ошибка сервера' }, { status: 500 })
  }
}
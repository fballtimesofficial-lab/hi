import { NextRequest, NextResponse } from 'next/server'
import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key'

// Mock admin data
const mockAdmins = [
  {
    id: '1',
    email: 'admin@delivery.com',
    password: '$2b$10$OnF4h1uCL1DDTGfppH1tyu5Bpd3Lc5ye505LTJZNW4oGj4oLfGev.', // 'admin123' hashed
    name: 'Admin User',
    role: 'SUPER_ADMIN',
    isActive: true
  },
  {
    id: '2',
    email: 'middle@delivery.com',
    password: '$2b$10$OnF4h1uCL1DDTGfppH1tyu5Bpd3Lc5ye505LTJZNW4oGj4oLfGev.', // 'admin123' hashed
    name: 'Middle Admin',
    role: 'MIDDLE_ADMIN',
    isActive: true
  }
]

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email и пароль обязательны' },
        { status: 400 }
      )
    }

    // Find admin by email in mock data
    const admin = mockAdmins.find(a => a.email === email)

    if (!admin) {
      return NextResponse.json(
        { error: 'Неверные учетные данные' },
        { status: 401 }
      )
    }

    // Check password
    const isPasswordValid = await bcrypt.compare(password, admin.password)
    
    if (!isPasswordValid) {
      return NextResponse.json(
        { error: 'Неверные учетные данные' },
        { status: 401 }
      )
    }

    // Check if admin is active
    if (!admin.isActive) {
      return NextResponse.json(
        { error: 'Аккаунт деактивирован' },
        { status: 401 }
      )
    }

    // Generate JWT token
    const token = jwt.sign(
      { 
        id: admin.id, 
        email: admin.email, 
        role: admin.role 
      },
      JWT_SECRET,
      { expiresIn: '24h' }
    )

    console.log(`✅ Admin login: ${admin.name} (${admin.email})`)

    return NextResponse.json({
      token,
      user: {
        id: admin.id,
        email: admin.email,
        name: admin.name,
        role: admin.role
      }
    })

  } catch (error) {
    console.error('Login error:', error)
    return NextResponse.json(
      { error: 'Внутренняя ошибка сервера' },
      { status: 500 }
    )
  }
}